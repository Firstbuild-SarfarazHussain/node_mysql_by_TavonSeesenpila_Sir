var express = require('express');
var router = express.Router();

var mysql = require('mysql');
var db = mysql.createPool({
  host: 'localhost',
  user:'root',
  password:'root#123',
  database: 'EmpDB',
  debug: false,
  ssl  : {
    // DO NOT DO THIS
    // set up your ca correctly to trust the connection
    rejectUnauthorized: false
  }
})


/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

router.get('/testconnect', function(req, res, next){
  if(db != null){
    res.send('Connected to DB')
  }else{
    res.send('Connection Failed');
  }
});

router.get('/selective', function (req, res, next){
  db.query('SELECT * FROM Employee', function (error, results, fields){
    
    // Handle error after the release.
    if (error){ throw error; }
    else{
      res.render('select', { 
        EmpID: results.EmpID
      });
    }
    

    // res.render('select', {
    //   EmpID: req.EmpID
    // });

  });
  db.end(function(err) {
    console.log('The connection is terminated now');
  });
});



module.exports = router;
